<script setup lang="ts">
import { computed } from 'vue'

// Relative Imports: Vite bundelt die Assets beim Konsumieren des Themes mit.
import wordmarkOnLight from '../assets/db-systel-wordmark-on-light.svg'
import wordmarkOnDark from '../assets/db-systel-wordmark-on-dark.svg'

/**
 * DB-Wortmarke (Logo mit Schriftzug).
 *
 * `variant` steuert, welche Asset-Variante genutzt wird:
 *   - 'auto'  (Default): folgt dem globalen Light/Dark-Mode (--db-wordmark)
 *   - 'onLight': dunkle Wortmarke – für hellen Untergrund (z.B. weiße Box)
 *   - 'onDark' : helle Wortmarke – für dunklen Untergrund
 */
const props = withDefaults(
  defineProps<{
    size?: string
    variant?: 'auto' | 'onLight' | 'onDark'
  }>(),
  { size: '3.5rem', variant: 'auto' },
)

const bg = computed(() => {
  if (props.variant === 'onLight')
    return `url(${wordmarkOnLight})`
  if (props.variant === 'onDark')
    return `url(${wordmarkOnDark})`
  return 'var(--db-wordmark)'
})
</script>

<template>
  <div
    class="db-wordmark"
    :style="{ height: size, backgroundImage: bg }"
    role="img"
    aria-label="DB Systel"
  />
</template>

<style scoped>
.db-wordmark {
  position: absolute;
  top: 1.4rem;
  left: 3.5rem;
  z-index: 20;
  aspect-ratio: 543.6 / 140.3;
  background-repeat: no-repeat;
  background-position: left center;
  background-size: contain;
}
</style>
