<script setup lang="ts">
/**
 * "DB Schwelle" – die roten Streifen als Deko-Element unten rechts.
 * `sm` = kleine Variante für Content-Folien (wie im PPT-Master).
 * Standard = breite Variante für Cover/Section/Statement/Ende.
 */
withDefaults(defineProps<{ sm?: boolean }>(), { sm: false })
</script>

<template>
  <div class="db-sleepers" :class="{ 'db-sleepers--sm': sm }" aria-hidden="true" />
</template>
