<script setup lang="ts">
// Relativer Import: Vite bundelt das Asset automatisch mit, wenn das Theme
// konsumiert wird (kein Theme-eigener public-Ordner nötig).
import dbLogo from '../assets/db-logo.svg'

/**
 * Das rote DB-Logo (Rechteck). Farbe ist in beiden Modi identisch (DB Rot),
 * daher genügt eine Variante. Position: oben rechts (wie im PPT-Master).
 */
withDefaults(
  defineProps<{
    /** Höhe des Logos, z.B. "2.2rem" */
    size?: string
  }>(),
  { size: '2.2rem' },
)
</script>

<template>
  <img
    class="db-logo"
    :src="dbLogo"
    alt="DB Logo"
    :style="{ height: size }"
  />
</template>

<style scoped>
.db-logo {
  position: absolute;
  top: 1.4rem;
  right: 2.5rem;
  z-index: 20;
  width: auto;
}
</style>
