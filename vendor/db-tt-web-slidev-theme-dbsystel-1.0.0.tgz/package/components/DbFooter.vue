<script setup lang="ts">
import { computed } from 'vue'

/**
 * DB-Systel-Fusszeile analog zum PowerPoint-Master:
 * "Firma | Name | Abteilung | Datum"  (unten links)
 * Foliennummer (unten rechts, fett)
 * Optionaler Klassifizierungshinweis (oben links)
 *
 * Werte kommen aus der Headmatter-`configs` (siehe README) und können
 * pro Folie via Frontmatter überschrieben werden.
 *
 * `$slidev`, `$page` und `$frontmatter` sind in Slidev-SFCs global
 * verfügbar (Auto-Inject) und müssen weder importiert noch deklariert werden.
 */
/**
 * `sleepers`     blendet die kleine "DB Schwelle" (S-Variante) oberhalb der
 *                Seitenzahl ein. Nur für Content-Layouts, die selbst keine
 *                große Schwelle rendern (DB-Regel: pro Layout nur EINE Schwelle).
 * `bigSleepers`  signalisiert, dass das Layout die große Standardschwelle am
 *                unteren Rand rendert. Dann wird die Seitenzahl angehoben,
 *                damit sie nicht auf den roten Streifen liegt (Lesbarkeit).
 */
const props = withDefaults(defineProps<{ sleepers?: boolean; bigSleepers?: boolean }>(), {
  sleepers: false,
  bigSleepers: false,
})

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const configs = computed<Record<string, any>>(
  () => ($slidev?.configs?.configs as Record<string, any>) ?? {},
)

// Frontmatter der einzelnen Folie darf einzelne Werte überschreiben
const fm = computed<Record<string, any>>(() => ($frontmatter as Record<string, any>) ?? {})

const footerParts = computed(() => {
  const c = configs.value
  return [c.company, c.author, c.unit, c.date]
    .map((v) => (typeof v === 'string' ? v.trim() : v))
    .filter(Boolean)
})

const classification = computed<string>(
  () => (fm.value.classification ?? configs.value.classification ?? '').toString().trim(),
)

/*
 * Auf Hero-Layouts mit großer Standardschwelle (statement/quote/fact/end)
 * wird die Fußzeilen-Metazeile ausgeblendet, damit sie nicht mit den roten
 * Streifen der Schwelle kollidiert (DB-CD: Schwelle wird nicht von Text
 * überlagert, Lesbarkeit). Die Seitenzahl bleibt – angehoben – erhalten.
 */
const showFooter = computed(() => fm.value.footer !== false && !props.bigSleepers)
const showPageNumber = computed(() => fm.value.pageNumber !== false)
const page = computed(() => (typeof $page === 'number' ? $page : $page?.value ?? 0))
</script>

<template>
  <div class="db-chrome" aria-hidden="false">
    <div v-if="classification" class="db-classification">
      {{ classification }}
    </div>

    <div v-if="showFooter && footerParts.length" class="db-footer">
      {{ footerParts.join('  |  ') }}
    </div>

    <div v-if="showPageNumber" class="db-page-block" :class="{ 'db-page-block--raised': bigSleepers }">
      <div v-if="sleepers" class="db-page-sleepers" />
      <div class="db-page-number">
        {{ page }}
      </div>
    </div>
  </div>
</template>

<style scoped>
.db-chrome {
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 20;
  font-family: 'DB Neo Office', var(--slidev-fonts-sans);
}

.db-classification {
  position: absolute;
  top: 0.5rem;
  left: 3.5rem;
  font-size: 0.7rem;
  /* Hinweis/Klassifizierung = zulässiger roter Text (mode-aware Akzent) */
  color: var(--db-accent);
  opacity: 0.8;
}

.db-footer {
  position: absolute;
  bottom: 0.9rem;
  left: 3.5rem;
  font-size: 0.72rem;
  color: var(--db-fg-muted);
}

/*
 * Seitenzahl mit darüberliegender "DB Schwelle" (rote Streifen).
 * Beide Elemente sind rechtsbündig gestapelt, sodass die Schwelle
 * direkt oberhalb der Foliennummer sitzt (moderner DB-2026-Look).
 */
.db-page-block {
  position: absolute;
  bottom: 0.9rem;
  right: 2.5rem;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 0.3rem;
}

/*
 * Auf Layouts mit großer Standardschwelle sitzt die Seitenzahl höher,
 * damit sie über den roten Streifen zu liegen kommt und lesbar bleibt.
 * Die Schwelle (675:36) nimmt 66% der Breite ein → sichtbare Höhe
 * ~6% der Folienhöhe. ~8% Abstand vom unteren Rand hält die Zahl frei.
 */
.db-page-block--raised {
  bottom: 8%;
}

/*
 * S-Variante der Schwelle (11 Streifen, 5,43:1) – für kleine
 * Anwendungen laut DB-CD. Proportional gerendert (auto Breite über
 * feste Höhe), damit die Streifenproportion nicht verzerrt wird.
 */
.db-page-sleepers {
  height: 0.5rem;
  width: 2.72rem; /* 0.5rem * 5.43 ≈ Motivbreite bei fester Höhe */
  background-image: var(--db-sleepers-s);
  background-repeat: no-repeat;
  background-position: right bottom;
  background-size: auto 100%;
}

.db-page-number {
  font-size: 0.72rem;
  font-weight: 700;
  line-height: 1;
  color: var(--db-fg);
}
</style>
