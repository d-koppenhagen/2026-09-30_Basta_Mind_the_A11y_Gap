<script setup lang="ts">
/**
 * Die große "DB Schwelle" als vertikaler Vorhang über die rechte Folienseite.
 * Entspricht dem Cover-/Titel-Layout des PPT-Masters:
 *   x = 66.93%, Breite = 33.07%, volle Höhe.
 * Farbe subtil: dunkel auf dunklem, hellgrau auf hellem Hintergrund
 * (via CSS-Variable --db-curtain).
 */
</script>

<template>
  <div class="db-curtain" aria-hidden="true" />
</template>

<style scoped>
.db-curtain {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  width: 33.07%;
  background-image: var(--db-curtain);
  background-repeat: no-repeat;
  background-position: right center;
  background-size: 100% 100%;
  pointer-events: none;
  z-index: 0;
}
</style>
