// inherit from base layouts, remove it to get full customizations
import '@slidev/client/styles/layouts-base.css'
import './fonts.css'
import './variables.css'
import './layout.css'
import './layouts.css'
