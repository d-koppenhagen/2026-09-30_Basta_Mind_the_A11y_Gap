// Type shims for static asset imports so `import logo from './x.svg'`
// type-checks in the theme's Vue components. At runtime Vite resolves these
// imports to the bundled asset URL (a string).
declare module '*.svg' {
  const src: string
  export default src
}
