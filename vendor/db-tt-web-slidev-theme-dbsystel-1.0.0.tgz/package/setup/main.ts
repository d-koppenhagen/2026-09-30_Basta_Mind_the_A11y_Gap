import { defineAppSetup } from '@slidev/types'

// Marken-Assets werden als ES-Module importiert, damit Vite sie über den
// JS-Asset-Graph auflöst: gehasht, mit korrektem `base`-Prefix und damit
// auch beim Deploy unter einem Unterpfad (z. B. GitLab/GitHub Pages via
// `--base /repo/`) funktionsfähig.
//
// Hintergrund: Werden dieselben Assets stattdessen per CSS `url('../assets/…')`
// in einer Theme-Stylesheet-Datei referenziert, kann Vite den Pfad im
// Slidev-`styles`-Kontext nicht statisch auflösen. Er landet dann roh als
// `/db/…` ohne `base`-Prefix und läuft beim Deploy unter einem Unterpfad
// ins Leere (404). Der Import-Weg vermeidet das.
import wordmarkOnLight from '../assets/db-systel-wordmark-on-light.svg'
import wordmarkOnDark from '../assets/db-systel-wordmark-on-dark.svg'
import sleepersRed from '../assets/db-sleepers-red.svg'
import sleepersRedS from '../assets/db-sleepers-red-s.svg'
import curtainLight from '../assets/db-curtain-light.svg'
import curtainDark from '../assets/db-curtain-dark.svg'

/**
 * Setzt die Marken-Asset-CSS-Variablen aus importierten (base-korrekten)
 * URLs. Light-Werte auf `:root`, Dark-Werte auf `html.dark` – identisches
 * Verhalten wie zuvor, nur mit auflösbaren Pfaden.
 */
export default defineAppSetup(() => {
  if (typeof document === 'undefined')
    return

  const style = document.createElement('style')
  style.id = 'db-theme-brand-assets'
  style.textContent = `
:root {
  /* Mode-abhängige Wortmarke (folgt Light/Dark). */
  --db-wordmark: url("${wordmarkOnLight}");
  /* Mode-UNabhängige Varianten – für Layouts/Decks, die eine bestimmte
     Wortmarke erzwingen müssen (z. B. helle Wortmarke auf einem Foto-Cover),
     ohne hartkodierte Asset-Pfade. Base-korrekt via Import. */
  --db-wordmark-on-light: url("${wordmarkOnLight}");
  --db-wordmark-on-dark: url("${wordmarkOnDark}");
  --db-sleepers: url("${sleepersRed}");
  --db-sleepers-s: url("${sleepersRedS}");
  --db-curtain: url("${curtainLight}");
}
html.dark {
  --db-wordmark: url("${wordmarkOnDark}");
  --db-sleepers: url("${sleepersRed}");
  --db-sleepers-s: url("${sleepersRedS}");
  --db-curtain: url("${curtainDark}");
}
`
  document.head.appendChild(style)
})
