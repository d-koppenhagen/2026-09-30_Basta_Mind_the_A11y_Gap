import type { CSSProperties } from 'vue'

/**
 * Löst einen Asset-Pfad relativ zur konfigurierten Vite-`base` auf.
 * Absolute Pfade (beginnend mit `/`) zeigen im `public/`-Ordner auf die
 * App-Wurzel. Wird die Präsentation unter einem Unterpfad deployed
 * (z. B. GitLab/GitHub Pages via `--base /repo/`), muss die `base`
 * vorangestellt werden, sonst laufen die URLs ins Leere (404).
 * Externe URLs und relative Pfade bleiben unverändert.
 */
export function resolveAssetUrl(url?: string): string | undefined {
  if (!url)
    return url

  // Externe URLs und data-URIs unverändert lassen
  if (/^(?:[a-z]+:)?\/\//i.test(url) || url.startsWith('data:'))
    return url

  if (url.startsWith('/')) {
    const base = import.meta.env.BASE_URL ?? '/'
    return `${base.replace(/\/$/, '')}${url}`
  }

  return url
}

/**
 * Erzeugt Style-Angaben für einen Folien-Hintergrund.
 * Ist der Wert eine Farbe (#, rgb, hsl, benannte Farbe ohne Slash/Punkt),
 * wird sie als `background` gesetzt, sonst als `background-image`.
 */
export function handleBackground(background?: string, cover = true): CSSProperties {
  if (!background)
    return {}

  const isColor
    = background.startsWith('#')
    || background.startsWith('rgb')
    || background.startsWith('hsl')
    || /^[a-z]+$/i.test(background)

  if (isColor) {
    return { background }
  }

  return {
    backgroundImage: `url("${resolveAssetUrl(background)}")`,
    backgroundSize: cover ? 'cover' : 'contain',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
  }
}
