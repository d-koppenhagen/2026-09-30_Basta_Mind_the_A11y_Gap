<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout two-cols" :style="style">
    <DbLogo />
    <div class="slidev-layout-content">
      <div v-if="$slots.default" class="col-top">
        <slot />
      </div>
      <div class="grid grid-cols-2 gap-8 mt-2">
        <div class="col-left">
          <slot name="left" />
        </div>
        <div class="col-right">
          <slot name="right" />
        </div>
      </div>
    </div>
    <DbFooter sleepers />
  </div>
</template>
