<script setup lang="ts">
import { computed } from 'vue'
import { resolveAssetUrl } from '../utils/layoutHelper'

const props = defineProps<{ image?: string }>()
const style = computed(() => ({
  backgroundImage: props.image ? `url("${resolveAssetUrl(props.image)}")` : undefined,
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  backgroundRepeat: 'no-repeat',
}))
</script>

<template>
  <div class="slidev-layout image h-full w-full" :style="style">
    <slot />
  </div>
</template>
