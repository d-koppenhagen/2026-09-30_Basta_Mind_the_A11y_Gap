<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbSleepers from '../components/DbSleepers.vue'
import DbWordmark from '../components/DbWordmark.vue'

/**
 * Abschluss-Folie mit Kontakt (PPT-Master: "Ende Kontakt dark/light").
 *
 * Große Abschluss-Headline (z.B. "Danke") und darunter ein Kontaktblock.
 * Der Kontaktblock wird über den `::contact::`-Slot oder – als Fallback –
 * über den restlichen Folieninhalt befüllt.
 *
 * Verwendung:
 * ---
 * layout: end-contact
 * ---
 * # Danke
 *
 * ::contact::
 *
 * **Vorname Nachname**
 * Rolle · DB Systel GmbH
 * vorname.nachname@deutschebahn.com
 */
const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout end-contact" :style="style">
    <DbWordmark class="end-contact-wordmark" />
    <div class="end-contact-inner">
      <div class="end-contact-title">
        <slot />
      </div>
      <div class="end-contact-details">
        <slot name="contact" />
      </div>
    </div>
    <DbSleepers />
  </div>
</template>

<style scoped>
.slidev-layout.end-contact {
  position: relative;
  height: 100%;
  padding: 0 3.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
}

.end-contact-wordmark {
  top: 1.4rem !important;
  left: 3.5rem !important;
  height: 3.5rem !important;
}

.end-contact-inner {
  width: 100%;
  max-width: 80%;
}

.end-contact-title :deep(h1) {
  font-size: 5rem;
  line-height: 1;
  font-weight: 900;
  margin: 0 0 1.5rem 0;
}

.end-contact-title :deep(h1)::after {
  content: none;
}

/* Kontaktblock: Lesetext in "DB Neo Office", klare Struktur */
.end-contact-details :deep(p) {
  font-size: 1.25rem;
  line-height: 1.5;
  margin: 0.1rem 0;
}

.end-contact-details :deep(strong) {
  font-family: 'DB Neo Office Head', 'DB Neo Office', var(--slidev-fonts-sans);
  font-weight: 900;
}

.end-contact-details :deep(a) {
  color: var(--db-link);
  text-decoration: underline;
  text-underline-offset: 3px;
}
</style>
