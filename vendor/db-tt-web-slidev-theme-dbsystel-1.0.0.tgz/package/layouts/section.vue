<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'
import DbSleepers from '../components/DbSleepers.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout section" :style="style">
    <DbLogo />
    <slot />
    <DbSleepers />
    <DbFooter big-sleepers />
  </div>
</template>
