<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout center h-full grid" :style="style" style="align-content: center; justify-items: center; text-align: center;">
    <DbLogo />
    <div class="max-w-4xl">
      <slot />
    </div>
    <DbFooter sleepers />
  </div>
</template>
