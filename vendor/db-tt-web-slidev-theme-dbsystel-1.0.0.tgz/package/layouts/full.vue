<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout full h-full w-full" :style="style">
    <slot />
  </div>
</template>
