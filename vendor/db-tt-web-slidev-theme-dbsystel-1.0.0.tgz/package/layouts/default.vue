<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout default" :style="style">
    <DbLogo />
    <div class="slidev-layout-content">
      <slot />
    </div>
    <DbFooter sleepers />
  </div>
</template>
