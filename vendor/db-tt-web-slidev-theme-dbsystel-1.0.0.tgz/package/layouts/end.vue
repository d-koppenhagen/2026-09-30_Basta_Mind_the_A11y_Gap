<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbSleepers from '../components/DbSleepers.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout end" :style="style">
    <div class="my-auto">
      <slot />
    </div>
    <DbSleepers />
  </div>
</template>
