<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbSleepers from '../components/DbSleepers.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout fact h-full grid" :style="style" style="align-content: center; justify-items: center; text-align: center;">
    <div class="db-fact">
      <slot />
    </div>
    <DbSleepers />
    <DbFooter big-sleepers />
  </div>
</template>

<style scoped>
.db-fact :deep(h1) {
  font-size: 6rem;
  line-height: 1;
  /* DB 2026: Schrift ist nie bunt. Große, expressive Headline in
   * Cold Black (hell) bzw. White (dunkel) statt DB Red. */
  color: var(--db-fg);
  font-weight: 900;
}
.db-fact :deep(p) {
  font-size: 1.5rem;
  color: var(--db-fg-muted);
}
</style>
