<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbSleepers from '../components/DbSleepers.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout quote h-full grid" :style="style" style="align-content: center;">
    <div class="db-quote max-w-4xl">
      <slot />
    </div>
    <DbSleepers />
    <DbFooter big-sleepers />
  </div>
</template>

<style scoped>
.db-quote :deep(blockquote) {
  border-left: 4px solid var(--db-red);
  border-radius: 0; /* DB 2026: keine abgerundeten Kanten */
  padding: 0.25rem 0 0.25rem 1.5rem;
  margin: 0;
  background: transparent;
  font-size: 2rem;
  line-height: 1.5;
  font-family: 'DB Neo Office Head', 'DB Neo Office', var(--slidev-fonts-sans);
  color: var(--db-fg);
}

.db-quote :deep(blockquote p) {
  margin: 0;
  line-height: 1.4;
  font-size: inherit;
}
</style>
