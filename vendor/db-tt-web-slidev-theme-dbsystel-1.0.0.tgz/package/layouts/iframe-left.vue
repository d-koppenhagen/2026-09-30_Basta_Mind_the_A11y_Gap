<script setup lang="ts">
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

defineProps<{ url?: string }>()
</script>

<template>
  <div class="slidev-layout image-left">
    <iframe v-if="url" :src="url" class="w-full h-full border-0" />
    <div class="slidev-layout-content">
      <DbLogo />
      <slot />
    </div>
    <DbFooter sleepers />
  </div>
</template>
