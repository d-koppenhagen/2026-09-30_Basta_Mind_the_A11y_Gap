<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbWordmark from '../components/DbWordmark.vue'
import DbCurtain from '../components/DbCurtain.vue'

const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout intro" :style="style">
    <DbCurtain />
    <DbWordmark class="cover-wordmark" />
    <div class="cover-content">
      <slot />
    </div>
  </div>
</template>
