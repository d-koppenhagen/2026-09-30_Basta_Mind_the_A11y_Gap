<script setup lang="ts">
defineProps<{ url?: string }>()
</script>

<template>
  <div class="slidev-layout iframe h-full w-full">
    <iframe v-if="url" :src="url" class="w-full h-full border-0" />
    <slot />
  </div>
</template>
