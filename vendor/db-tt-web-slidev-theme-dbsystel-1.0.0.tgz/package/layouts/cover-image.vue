<script setup lang="ts">
import { computed } from 'vue'
import { resolveAssetUrl } from '../utils/layoutHelper'
import DbWordmark from '../components/DbWordmark.vue'
import DbSleepers from '../components/DbSleepers.vue'

/**
 * Bild-Cover (PPT: "Titel Bild"). Formatfüllendes Hintergrundbild,
 * darüber links eine Box (hell oder dunkel) mit Wortmarke, Titel,
 * Untertitel und Datum sowie einer kleinen Schwelle am Boxrand.
 *
 * Props:
 *   image    – Bild-URL (formatfüllend)
 *   boxTheme – 'light' (weiße Box, dunkler Text) | 'dark' (dunkle Box, heller Text)
 */
const props = withDefaults(
  defineProps<{ image?: string, boxTheme?: 'light' | 'dark' }>(),
  { boxTheme: 'light' },
)

const bgStyle = computed(() => ({
  backgroundImage: props.image ? `url("${resolveAssetUrl(props.image)}")` : undefined,
}))
</script>

<template>
  <div class="slidev-layout cover-image" :style="bgStyle">
    <div class="cover-image-box" :class="`box-${boxTheme}`">
      <DbWordmark class="cover-image-wordmark" :variant="boxTheme === 'dark' ? 'onDark' : 'onLight'" />
      <div class="cover-image-content">
        <slot />
      </div>
      <DbSleepers />
    </div>
  </div>
</template>

<style scoped>
.slidev-layout.cover-image {
  position: relative;
  height: 100%;
  width: 100%;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  padding: 0;
  display: block;
}

.cover-image-box {
  position: absolute;
  top: 8%;
  left: 4.82%;
  width: 52%;
  height: 84%;
  box-sizing: border-box;
  padding: 3.5% 3% 4%;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.box-light,
.box-light :deep(h1),
.box-light :deep(h2),
.box-light :deep(p) {
  color: var(--db-cold-black);
}

.box-light {
  background: var(--db-white);
}

.box-dark,
.box-dark :deep(h1),
.box-dark :deep(h2),
.box-dark :deep(p) {
  color: var(--db-white);
}

.box-dark {
  background: var(--db-cold-black);
}

.cover-image-wordmark {
  top: 6% !important;
  left: 6% !important;
  height: 12% !important;
}

.cover-image-content :deep(h1) {
  font-size: 3rem;
  line-height: 1.05;
  font-weight: 700;
  margin: 0 0 0.4rem 0;
}

.cover-image-content :deep(h1 + p),
.cover-image-content :deep(h2) {
  font-size: 1.6rem;
  font-weight: 400;
  margin: 0.3rem 0 0.6rem 0;
}
</style>
