<script setup lang="ts">
import { computed } from 'vue'
import { handleBackground } from '../utils/layoutHelper'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

/**
 * Inhaltsverzeichnis / Agenda (PPT-Master: "Inhaltsverzeichnis dark/light").
 *
 * Titel oben, darunter die Kapitelliste. Eine nummerierte Liste (`1. …`)
 * wird als Agenda mit großen, roten Ordnungszahlen dargestellt; eine
 * einfache Aufzählung nutzt die DB-typischen Gedankenstrich-Bullets.
 *
 * Verwendung:
 * ---
 * layout: agenda
 * ---
 * # Agenda
 *
 * 1. Einleitung
 * 2. Hauptteil
 * 3. Zusammenfassung
 */
const props = defineProps<{ background?: string }>()
const style = computed(() => handleBackground(props.background))
</script>

<template>
  <div class="slidev-layout agenda" :style="style">
    <DbLogo />
    <div class="agenda-content">
      <slot />
    </div>
    <DbFooter sleepers />
  </div>
</template>

<style scoped>
.slidev-layout.agenda {
  position: relative;
  height: 100%;
}

.agenda-content {
  max-width: 80%;
}

/*
 * Nummerierte Agenda: große, rote Ordnungszahlen (DB-Akzent), klar
 * strukturiert. Die Ziffer ist ein Gestaltungselement (kein Fließtext),
 * daher als Akzentfarbe zulässig.
 */
.agenda-content :deep(ol) {
  list-style: none;
  padding-left: 0;
  counter-reset: agenda;
  margin-top: 1.5rem;
}

.agenda-content :deep(ol > li) {
  counter-increment: agenda;
  position: relative;
  padding-left: 3.75rem;
  margin-bottom: 1.1rem;
  font-size: 1.5rem;
  line-height: 1.3;
  min-height: 2.5rem;
  display: flex;
  align-items: center;
}

.agenda-content :deep(ol > li)::before {
  content: counter(agenda, decimal-leading-zero);
  position: absolute;
  left: 0;
  top: 0;
  font-family: 'DB Neo Office Head', 'DB Neo Office', var(--slidev-fonts-sans);
  font-weight: 900;
  font-size: 2rem;
  line-height: 1.25;
  color: var(--db-accent);
  font-variant-numeric: tabular-nums;
}

/* Einfache Aufzählung: etwas größere DB-Bullets für die Agenda */
.agenda-content :deep(ul > li) {
  font-size: 1.5rem;
  line-height: 1.4;
  margin-bottom: 0.9rem;
}
</style>
