<script setup lang="ts">
import { computed } from 'vue'
import DbFooter from '../components/DbFooter.vue'
import DbLogo from '../components/DbLogo.vue'

const props = defineProps<{ image?: string }>()
const imageStyle = computed(() => ({
  backgroundImage: props.image ? `url("${props.image}")` : undefined,
}))
</script>

<template>
  <div class="slidev-layout image-left">
    <div class="db-image-cover" :style="imageStyle" />
    <div class="slidev-layout-content">
      <DbLogo />
      <slot />
    </div>
    <DbFooter sleepers />
  </div>
</template>
