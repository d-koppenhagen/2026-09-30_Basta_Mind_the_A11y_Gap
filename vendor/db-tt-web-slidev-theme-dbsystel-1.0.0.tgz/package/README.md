# slidev-theme-dbsystel

> This Project is in preview and evaluation state

A DB Systel theme for [Slidev](https://github.com/slidevjs/slidev), based on the
official PowerPoint master "DB 2026". Supports light and dark mode.

## Fonts

The theme uses the DB corporate typefaces from the **DB Type 3.1** family,
following the DB 2026 rules for functional ("sachliche") applications such as
presentations and office documents:

| Usage                    | Font family           | Weight / cut          |
|--------------------------|-----------------------|-----------------------|
| Headlines (`h1`–`h4`)    | `DB Neo Office Head`  | `Black` (900), mixed case |
| Body text, lists, footer | `DB Neo Office`       | `Regular` (400), `Bold` (700) for emphasis |
| Code (`code` / `pre`)    | monospace fallback    | `Consolas`/`Monaco`/`monospace` |

### The fonts are NOT bundled with this theme

> The DB Type fonts are **licensed** corporate fonts and must **not** be
> redistributed (e.g. via GitHub, npm or a public CDN). Therefore this theme
> ships **no font files at all**. It references the fonts via `local()` only
> (see [`styles/fonts.css`](./styles/fonts.css)), i.e. it uses the copy that is
> **installed on the machine that renders the slides**.

### Prerequisite: install the fonts locally

To render slides with the correct typography, install **DB Neo Office** and
**DB Neo Office Head** on your system:

- **macOS:** open the font files (`.otf`/`.ttf`/`.woff2`) and click *Install*, or
  add them via the *Font Book* ("Schriftensammlung") app.
- **Windows:** right-click the font files → *Install* (or *Install for all users*).
- **Linux:** copy them into `~/.local/share/fonts` (or `/usr/share/fonts`) and
  run `fc-cache -f`.

The theme registers these `local()` names (full name and PostScript name), so any
of them will be matched: `DB Neo Office`, `DBNeoOffice-Regular/-Bold/-Italic/-BoldItalic`,
`DB Neo Office Head`, `DBNeoOfficeHead-Regular/-Black/-Italic/-BlackItalic`.

You can verify the fonts are picked up in the browser console:

```js
document.fonts.check('16px "DB Neo Office"')        // → true when installed
document.fonts.check('900 40px "DB Neo Office Head"') // → true when installed
```

### Fallback behavior

If the fonts are **not** installed, the theme falls back gracefully to the
system sans-serif stack defined in `package.json` (`slidev.defaults.fonts`):

```
"DB Neo Office", Helvetica, Arial, sans-serif
```

So slides always render — with `Helvetica`/`Arial` instead of DB Neo Office. Only
the typography differs; layout, colors and spacing are unaffected.

## Colors

The color tokens in `styles/variables.css` are taken 1:1 from the official DB
brand portal ([Markenfarben](https://marketingportal.extranet.deutschebahn.com/neues-design/Markenfarben))
and cover the full **Grey**, **DB Red**, **Lilac** and **Green** scales (`25`–`900`).
Semantic variables resolve per mode:

- **Light:** White background, Black text, `DB Red 500` (`#EC0016`) as the red
  accent / link color.
- **Dark:** Cold Black background, White text, `DB Red` (`#FF002B`) as the red
  accent (brighter red required for contrast on Cold Black).

Following the DB rules, text is never colored (only Black/White); red is reserved
for links, hints and accents and always paired with a second visual cue
(double-coding, e.g. underline). Corners are square throughout — the DB 2026
design language is strictly straight-edged (no `border-radius`).

## Usage

To consume the theme make sure to add the scope to your local `.npmrc`.

```text
@db-tt-web:registry=https://bahnhub.tech.rz.db.de/artifactory/api/npm/db-inner-source-npm-release-local/
```

This allows you to access the published theme.
Now you can install the theme via NPM:

```bash
npm i @db-tt-web/slidev-theme-dbsystel
```

Now, add the following frontmatter to your `slides.md` in a created slidev repo (`npm init slidev`).

<pre><code>---
theme: <b>dbsystel</b>
---</code></pre>

Last but not least, configure the variables as shown in section [Configuration](#configuration-footer-title-etc).

## Install (local repository)

Add the following frontmatter to your `slides.md`. Start Slidev then it will prompt you to install the theme automatically.

<pre><code>---
theme: <b>dbsystel</b>
---</code></pre>

Learn more about [how to use a theme](https://sli.dev/themes/use).

## Configuration (Footer Title, etc.)

The general information for the footer and title slide can be configured.
For adjusting the values in the repo which provides the template, you need to change the value in the `package.json` (`slidev` > `defaults` > `config`).
When configuring a consuming project, you need to add the config to the frontmatter part of your `slides.md`:

```yaml
---
theme: "@db-tt-web/slidev-theme-dbsystel"
# ...
title: My Title
configs:
  title: My Title in the footer
  author: "Firstname Lastname"
  social: "@my-social-handle"
  company: "DB Systel GmbH"
  unit: "Team XYZ"
  location: "Frankfurt"
  date: "01.09.2026"
  titleTemplate: "%s | DB Systel GmbH"
  classification: ""   # e.g. "DB Intern / DB internal" – empty = hidden
---
```

| key              | example value           | description                                              |
|------------------|-------------------------|----------------------------------------------------------|
| `title`          | Slidev Theme DB Systel  | The title for the presentation                           |
| `author`         | Firstname Lastname      | The name of the author or authors                        |
| `social`         | @my-social-handle       | Handles for social media accounts (e.g. for Twitter)     |
| `company`        | DB Systel GmbH          | The company name                                         |
| `unit`           | Team XYZ                | Information about the unit or team, etc.                 |
| `location`       | Frankfurt               | The city / location                                      |
| `date`           | 01.09.2026              | Date of presentation                                     |
| `titleTemplate`  | %s \| DB Systel GmbH    | Template for the browser tab title                       |
| `classification` | DB Intern / DB internal | Optional classification note (top left). Empty = hidden. |

The footer (bottom left) is composed of `company | author | unit | date`.
If a value is not configured, it is omitted from the footer.

### Classification note

The PowerPoint master shows a classification hint (e.g. "DB Intern / DB internal")
in the top-left corner. This theme leaves it **empty by default** (suitable for
public talks). To enable it, set `classification` in the `configs` block above, or
override it per slide in the frontmatter:

```yaml
---
classification: "DB Intern / DB internal"
---
```

### Hiding footer / page number per slide

Per slide you can hide the footer or the page number via frontmatter:

```yaml
---
footer: false       # hide the footer on this slide
pageNumber: false   # hide the page number on this slide
---
```

## Layouts

This theme provides the following layouts:

| layout        | description                                                        |
|---------------|--------------------------------------------------------------------|
| `cover`       | Title slide: wordmark top-left, title bottom-left, vertical "curtain" deco right |
| `cover-image` | Title slide with full-bleed image and a content box (`image:`, `boxTheme: light\|dark`) |
| `intro`       | Intro / about slide, similar to cover                              |
| `agenda`      | Table of contents / agenda ("Inhaltsverzeichnis"). Numbered list → red ordinals |
| `section`     | Chapter divider ("Kapiteltrenner")                                 |
| `default`     | Standard content slide (title, DB bullets, footer, logo)           |
| `two-cols`    | Two-column content (`::left::` / `::right::` slots)                |
| `statement`   | Large statement text                                               |
| `quote`       | Blockquote with red accent bar                                     |
| `fact`        | Big number / fact, centered                                        |
| `center`      | Centered content                                                   |
| `image`       | Full-bleed background image (`image:` prop)                        |
| `image-left`  | Image left, content right (`image:` prop)                          |
| `image-right` | Content left, image right (`image:` prop)                          |
| `iframe`      | Full-bleed iframe (`url:` prop)                                    |
| `iframe-left` | Iframe left, content right (`url:` prop)                           |
| `iframe-right`| Content left, iframe right (`url:` prop)                           |
| `full`        | Empty full-size canvas                                             |
| `end`         | Closing slide ("Danke")                                            |
| `end-contact` | Closing slide with a contact block (`::contact::` slot): name, role, email |
| `none`        | Slidev built-in, no styling                                        |

## Components

This theme provides the following components (auto-imported):

| component     | description                                                       |
|---------------|-------------------------------------------------------------------|
| `DbLogo`      | The red DB logo (top right). Prop: `size` (e.g. `2.2rem`).         |
| `DbWordmark`  | The "DB Systel" wordmark. Props: `size`, `variant` (`auto` \| `onLight` \| `onDark`; `auto` follows light/dark mode). |
| `DbSleepers`  | The red "DB Schwelle" stripes (bottom right). Prop: `sm` (small S-variant for content slides). |
| `DbCurtain`   | The large vertical "DB Schwelle" curtain on the right (cover).    |
| `DbFooter`    | Footer, page number and optional classification note. Props: `sleepers` (small Schwelle above the page number), `bigSleepers` (raises the page number and hides the footer meta line when a layout renders the large Schwelle). |

### `cover-image` usage

```yaml
---
layout: cover-image
image: /path/to/image.jpg
boxTheme: light   # or: dark
---

# Title of the presentation

Subtitle of the presentation

01.09.2026 | Location
```

## Styling notes

To have a better contrast for the footer on dark backgrounds, you can switch the style to a light text color.
Therefore please set either `dark-bg` or `light-text` to the slides frontmatter part:

```yaml
---
layout: image
image: 'https://example.org/my-dark-bg-image.jpg'
class: "light-text"
---
```

## Contributing

- `npm install`
- `npm run dev` to start theme preview of `example.md`
- Edit the `example.md` and style to see the changes
- `npm run export` to generate the preview PDF
- `npm run screenshot` to generate the preview PNG
